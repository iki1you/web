from flask import Flask
from data import db_session
from data.users import User
from data.jobs import Jobs
import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/blogs.db")
    db_sess = db_session.create_session()
    user = User()
    user.surname = "Scott"
    user.name = "Ridley"
    user.age = "21"
    user.position = "captain"
    user.speciality = "research engineer"
    user.address = "module_1"
    user.email = "scott_chief@mars.org"
    db_sess.add(user)

    user2 = User()
    user2.surname = "Smith"
    user2.name = "John"
    user2.age = "43"
    user2.position = "pilot"
    user2.speciality = "technical engineer"
    user2.address = "module_2"
    user2.email = "J0hn_Smith@mars.org"
    db_sess.add(user2)

    user3 = User()
    user3.surname = "Johnson"
    user3.name = "Bill"
    user3.age = "34"
    user3.position = "repairer"
    user3.speciality = "electronics engineer"
    user3.address = "module_3"
    user3.email = "Bill_Johnson@mars.org"
    db_sess.add(user3)

    user4 = User()
    user4.surname = "Harris"
    user4.name = "Steve"
    user4.age = "25"
    user4.position = "architect"
    user4.speciality = "design engineer"
    user4.address = "module_4"
    user4.email = "Steve_Harris@mars.org"
    db_sess.add(user4)

    job = Jobs()
    job.team_leader = 1
    job.job = 'deployment of residential modules 1 and 2'
    job.work_size = 15
    job.collaborators = '2, 3'
    job.is_finished = False
    db_sess.add(job)

    db_sess.commit()
    app.run()

if __name__ == '__main__':
    main()